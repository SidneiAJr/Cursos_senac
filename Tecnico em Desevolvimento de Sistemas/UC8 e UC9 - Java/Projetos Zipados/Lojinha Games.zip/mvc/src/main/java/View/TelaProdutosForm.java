package View;

import dao.JogoDAO; // Importa o Dao (que conversa com o mysql)
import java.util.List; // Importando o List
import javax.swing.JOptionPane; // Importando o JOPtion para avisos
import model.Jogo; // Importando o Modelo do jogo
import javax.swing.table.DefaultTableModel; // Importando os sistema de tabela
import util.ImageStorage; // Importa da imagem
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.ListSelectionModel;

// Essa e a tela principal(View)
// Ela herda Jframe; Uma janela Swing

public class TelaProdutosForm extends javax.swing.JFrame {
    // Cria o Dao , uma unica vez para usar em toda a tela
    /*
    =================================================
    O que ele fez?
    - Ele executa inserir/atualizar/excluir/listar
    =================================================
    */
    private final JogoDAO dao = new JogoDAO();
    //Guarda o ID selecionado na tabela
    // null => modo "novo cadastro"
    // numero -> modo "edição" de um item existente
    private Integer idSelecionado = null;
    // Guardar o arquivo de imagem que o usuario escolheu no computador
    // (Ainda não foi salvo) na pasta ./Imagem
    // Consctutor da tela 
    private File ImagemEscolhida;
    
    
    public TelaProdutosForm() {
        initComponents(); // Monta componentes do form
        configurarTabela(); // Configura clique / Seleção tabela
        recarregarTabela();
        novo();
    }
    
    // Logica (crud + Imagem)
    public void configurarTabela(){
        // Garante que so tem um item pode ser selecionado
        tb_info.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        //Listerner: dispara quando o usuario selecionar uma lista da tabela
        tb_info.getSelectionModel().addListSelectionListener(e ->{
            //Evita disparar duas vezes
            if(!e.getValueIsAdjusting()){
                //Pega a linha selecionada
                int row = tb_info.getSelectedRow();
                // Se realmente existe uma linha selecionada.....
                if(row>=0){
                    //Pega o ID (Coluna 0) da linha 
                    int id = (int) tb_info.getModel().getValueAt(row,0);
                    //carrega os dados do jogo nos campos para editar
                    carregarparaEdicao(id);
                }
            }
        });
    }
    
    private void carregarparaEdicao(int id){
        Jogo j = dao.buscarPorId(id);
        // Se Não encontro , não faz nada
        if(j==null)return;
        idSelecionado = j.getId();
        jt_titulo.setText(j.getTitulo());
        jt_plataforma.setText(j.getPlataforma());
        jt_preco.setText(String.valueOf(j.getPreco()));
        // Mostra o caminho Imagem
        jt_imagem.setText(j.getImagemPath() == null ? "Nenhuma Imagem": j.getImagemPath());
        // Ao carregar para edição , não obrigamos a escolher a imagem de novo
        ImagemEscolhida = null;
        //Mostra Inagem do produto
        Mostrarimagem(j.getImagemPath(),false); 
        
    }
    
    private void escolherImagem(){
        // Abre a Janela do Windows para escolher
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Escolha Nosso Jogo: ");
        //Mostra a janela
        int result = chooser.showOpenDialog(this);
        
        if(result == JFileChooser.APPROVE_OPTION){
            // Salvar o Arquivo escolhido
            ImagemEscolhida = chooser.getSelectedFile();
            // Mostra Preview | Imediatamente usando o caminho
            Mostrarimagem(ImagemEscolhida.getAbsolutePath(),true);
           jt_imagem.setText("Será copiado ao salvr (./Salvar)");
        }
    }
    
    private void salvarouAtualizar(){
        //Valida : impede salvar
        // Validação: impede salvar campos vazios
        if (jt_titulo.getText().isBlank() || jt_plataforma.getText().isBlank() || jt_preco.getText().isBlank()) {
            JOptionPane.showMessageDialog(this, "Preencha título, plataforma e preço.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Converte o preço do texto para double
        double preco;
        try {
            // Aceita "199,90" e transforma em "199.90"
            preco = Double.parseDouble(jt_preco.getText().replace(",", "."));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Preço inválido! Ex: 199.90", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Caminho final que será gravado no banco
        String caminhoImagem = null;

        // Se o usuário escolheu uma imagem nova agora...
        if (ImagemEscolhida != null) {
            // Copia para ./imagens e devolve o caminho relativo
            caminhoImagem = ImageStorage.salvarImagem(ImagemEscolhida);

        // Senão, se estamos editando um item existente...
        } else if (idSelecionado != null) {

            // Mantém a imagem atual do banco (não perde ao editar)
            Jogo atual = dao.buscarPorId(idSelecionado);
            if (atual != null) caminhoImagem = atual.getImagemPath();
        }

        // Monta o objeto Jogo com os dados do form
        Jogo j = new Jogo(
                jt_titulo.getText().trim(),
                jt_plataforma.getText().trim(),
                preco,
                caminhoImagem);
                // Se não tem ID selecionado => é cadastro (INSERT)
        if (idSelecionado == null) {
            dao.Inserir(j);
            JOptionPane.showMessageDialog(this, "Produto cadastrado!", "OK", JOptionPane.INFORMATION_MESSAGE);

        // Se tem ID => é edição (UPDATE)
        } else {
            j.setId(idSelecionado);
            dao.Atualizar(j);
            JOptionPane.showMessageDialog(this, "Produto atualizado!", "OK", JOptionPane.INFORMATION_MESSAGE);
        }

        // Atualiza a tabela e limpa o form
        recarregarTabela();
        novo();
        
    }
    
    private void Mostrarimagem(String caminho, boolean preview) {

    if (caminho == null || caminho.isBlank()) {
        lbl_capa.setIcon(null);
        lbl_capa.setText("Sem imagem");
        return;
    }

    File imgFile = new File(caminho);

    if (!imgFile.exists()) {
        lbl_capa.setIcon(null);
        lbl_capa.setText("Imagem não encontrada");
        return;
    }

    ImageIcon icon = new ImageIcon(caminho);
    Image img = icon.getImage().getScaledInstance(
            lbl_capa.getWidth(),
            lbl_capa.getHeight(),
            Image.SCALE_SMOOTH
    );

    lbl_capa.setIcon(new ImageIcon(img));
    lbl_capa.setText("");

    if (preview) {
        lbl_capa.setToolTipText("Pré-visualização (ainda não salva)");
    } else {
        lbl_capa.setToolTipText("Imagem salva");
    }
}


    public void recarregarTabela(){
     DefaultTableModel m = (DefaultTableModel) tb_info.getModel();

        // Limpa todas as linhas antes de recarregar
        m.setRowCount(0);

        // Busca lista do banco
        List<Jogo> lista = dao.Listar();

        // Adiciona cada jogo como uma nova linha da tabela
        for (Jogo j : lista) {
            m.addRow(new Object[]{ j.getId(), j.getTitulo(), j.getPlataforma(), j.getPreco(), j.getImagemPath() });
    }
    }
    
     private void excluir() {
        // Se não selecionou nada, não dá pra excluir
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um item para excluir.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Confirmação para evitar exclusões acidentais
        int confirm = JOptionPane.showConfirmDialog(this, "Excluir este produto?", "Confirmar", JOptionPane.YES_NO_OPTION);

        // Se confirmou...
        if (confirm == JOptionPane.YES_OPTION) {
            dao.Excluir(idSelecionado);
            JOptionPane.showMessageDialog(this, "Produto excluído!", "OK", JOptionPane.INFORMATION_MESSAGE);
            recarregarTabela();
            novo();
        }
    }
    
  
    private void novo(){
        //Voltando ao modo "novo cadastro"
        idSelecionado = null;
        //Esquece a imagem escoljioda no pc
        ImagemEscolhida = null;
        //Limpa campos
        jt_titulo.setText("");
        jt_preco.setText("");
        jt_plataforma.setText("");
        jt_imagem.setText("Nenhuma Imagem escolhida");
        
        // Limpa preview
        lbl_capa.setIcon(null);
        lbl_capa.setText("Selecione um Item: ");
        
        // Remove seleção da tabela
        tb_info.clearSelection();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jt_plataforma = new javax.swing.JTextField();
        jt_titulo = new javax.swing.JTextField();
        jt_preco = new javax.swing.JTextField();
        jt_imagem = new javax.swing.JTextField();
        btn_excluir = new javax.swing.JButton();
        btn_limpar = new javax.swing.JButton();
        btn_salvar = new javax.swing.JButton();
        btn_escolherimg = new javax.swing.JButton();
        pl_capa = new javax.swing.JPanel();
        lbl_img = new javax.swing.JPanel();
        lbl_capa = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_info = new javax.swing.JTable();
        btn_atualizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Cadastro | Inclusão | Exclusão\n", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 3, 18)); // NOI18N
        jLabel1.setText("Lojinha de Jogos");

        jLabel2.setText("Titulo");

        jLabel3.setText("Imagem (Upload):");

        jLabel4.setText("Plataforma");

        jLabel5.setText("Preço");

        jt_imagem.setEditable(false);

        btn_excluir.setText("Excluir");
        btn_excluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_excluirActionPerformed(evt);
            }
        });

        btn_limpar.setText("Limpar");
        btn_limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_limparActionPerformed(evt);
            }
        });

        btn_salvar.setText("Salvar | Editar");
        btn_salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_salvarActionPerformed(evt);
            }
        });

        btn_escolherimg.setText("Escolher Imagem");
        btn_escolherimg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_escolherimgActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jt_preco, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jt_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jt_plataforma, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(btn_escolherimg, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                                .addComponent(jt_imagem, javax.swing.GroupLayout.Alignment.LEADING))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btn_salvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_excluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_limpar)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jt_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jt_plataforma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jt_preco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(btn_escolherimg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jt_imagem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_salvar)
                    .addComponent(btn_excluir)
                    .addComponent(btn_limpar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pl_capa.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Capa ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N

        lbl_capa.setText("Selecione um Item:");

        javax.swing.GroupLayout lbl_imgLayout = new javax.swing.GroupLayout(lbl_img);
        lbl_img.setLayout(lbl_imgLayout);
        lbl_imgLayout.setHorizontalGroup(
            lbl_imgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbl_imgLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_capa)
                .addContainerGap(326, Short.MAX_VALUE))
        );
        lbl_imgLayout.setVerticalGroup(
            lbl_imgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbl_imgLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lbl_capa)
                .addContainerGap(496, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pl_capaLayout = new javax.swing.GroupLayout(pl_capa);
        pl_capa.setLayout(pl_capaLayout);
        pl_capaLayout.setHorizontalGroup(
            pl_capaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pl_capaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_img, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pl_capaLayout.setVerticalGroup(
            pl_capaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pl_capaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_img, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tb_info.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nome", "Plataforma", "Preço", "Imagem"
            }
        ));
        jScrollPane1.setViewportView(tb_info);

        btn_atualizar.setText("Atualizar");
        btn_atualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_atualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_atualizar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pl_capa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pl_capa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 522, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_atualizar)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_limparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_limparActionPerformed
        // TODO add your handling code here:
        novo();
    }//GEN-LAST:event_btn_limparActionPerformed

    private void btn_salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_salvarActionPerformed
        salvarouAtualizar();
    }//GEN-LAST:event_btn_salvarActionPerformed

    private void btn_excluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_excluirActionPerformed
        // TODO add your handling code here:
       excluir();
    }//GEN-LAST:event_btn_excluirActionPerformed

    private void btn_atualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_atualizarActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_btn_atualizarActionPerformed

    private void btn_escolherimgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_escolherimgActionPerformed
       // 1️⃣ Criar JFileChooser
      escolherImagem();
    
    
    }//GEN-LAST:event_btn_escolherimgActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaProdutosForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaProdutosForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaProdutosForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaProdutosForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaProdutosForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_atualizar;
    private javax.swing.JButton btn_escolherimg;
    private javax.swing.JButton btn_excluir;
    private javax.swing.JButton btn_limpar;
    private javax.swing.JButton btn_salvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jt_imagem;
    private javax.swing.JTextField jt_plataforma;
    private javax.swing.JTextField jt_preco;
    private javax.swing.JTextField jt_titulo;
    private javax.swing.JLabel lbl_capa;
    private javax.swing.JPanel lbl_img;
    private javax.swing.JPanel pl_capa;
    private javax.swing.JTable tb_info;
    // End of variables declaration//GEN-END:variables

    
}
