package dao;
import java.sql.SQLException;
import util.ConnectionFactory;
import java.sql.*;
import model.Jogo;
import java.util.ArrayList;
import java.util.List;


public class JogoDAO {
    private Connection connection;
    
    public JogoDAO() {
       try {
        this.connection = new ConnectionFactory().getConnection();
    } catch (SQLException e) {
        throw new RuntimeException("Não foi possível conectar ao banco no início da DAO: ", e);
    }
    }
    
    public void Inserir(Jogo jogo) {
        String sql = "INSERT INTO jogo (titulo,plataforma,preco,imagem_path) VALUES (?, ?,?,?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, jogo.getTitulo());
            stmt.setString(2, jogo.getPlataforma());
            stmt.setDouble(3, jogo.getPreco());
            stmt.setString(4, jogo.getImagemPath());
            
            stmt.executeLargeUpdate();
            System.out.println("Jogo salvo com sucesso!");
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar jogo: "+e.getMessage());
        }
    }
    
    //Update Atualizar
    
    public void Atualizar(Jogo jogo){
        String sql = "Update jogo set titulo = ? , plataforma =? , preco = ?, imagem_path=? where id=?";
        
        try(PreparedStatement stmt = connection.prepareStatement(sql)) {
            
        } catch (Exception e) {
        }
        
    }
    
}
